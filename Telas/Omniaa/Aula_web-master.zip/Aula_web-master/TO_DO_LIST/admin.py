from django.contrib import admin
from .models import Tarefas

admin.site.register(Tarefas)
# Register your models here.
