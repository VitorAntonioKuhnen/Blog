from django.apps import AppConfig


class ToDoListConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'TO_DO_LIST'
